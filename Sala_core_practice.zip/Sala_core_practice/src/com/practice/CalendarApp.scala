package com.practice

object CalendarApp extends App 
{
  println("Calendar")
  val mapCal=Map("January"->31,"February"->2)
  for(mapCal<- until mapCal)
  {
    
  }
  
}