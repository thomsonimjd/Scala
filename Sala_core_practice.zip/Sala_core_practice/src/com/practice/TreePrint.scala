package com.practice

object TreePrint extends App {

  println("Enter a Int no to printl Trees(-ve -Reverse**):")
  var a = readInt()
  var c = a * -1
  var b = c

  if (a < 0) {

    do {

      for (b <- 1 to b) {
        print("*")
      }

      println()
      c -= 1
      b = c
    } while (c != 0)
  } else {
    for (a <- 0 to a) {
      b = a;
      for (b <- 1 to b) {
        print("*")
      }
      println()
    }
  }

}