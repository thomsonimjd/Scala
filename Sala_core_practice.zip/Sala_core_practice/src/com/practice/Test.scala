package com.practice
 

 import java.util._
 import scala.collection.mutable.ListMap

object Test {
   def main(args: Array[String]) {
 
      // var mapCal = ListMap("January" -> 31, "February" -> 28, "March" -> 31, "April" -> 30, "May" -> 31, "June" -> 30, "July" -> 31, "August" -> 31, "September" -> 30, "October" -> 31, "November" -> 30, "December" -> 31)
       var calendar = new GregorianCalendar();
        calendar.set(2016, 5, 16); // 0 = January
        var day=calendar.get(Calendar.DAY_OF_WEEK)
        println(calendar.get(Calendar.DAY_OF_WEEK)+"\n");
      
       while(day!=7)
       {
         print("\tt")
         day+=1
       }
      
   }
 }
