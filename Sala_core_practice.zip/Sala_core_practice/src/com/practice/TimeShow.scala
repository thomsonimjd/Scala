

package com.practice

object TimeShow extends App 
{
  
   val tw=new PrintHrs
   println("24-hour  and   12-hour times")
   tw.t24hrs()
  
}
class PrintHrs
{
   def t24hrs()
  {
      val i=0
      val j=0
      var tm=12
      var am="am"
      var z="0"
      for(j<-0 to 23 )
      {
         if(j<10)
         {
           if(tm>=10)z=""else z="0"
           println(i+""+j+":00          "+z+""+tm+":00"+am)
         }
         else 
         {
           if(tm>=10)z=""else z="0"
             if(j>=12) am="pm" 
             println(j+":00          "+z+""+tm+":00"+am)
           
          }         
         if(tm==12)tm=0
         tm=tm+1
      }
   }
   
  
}
